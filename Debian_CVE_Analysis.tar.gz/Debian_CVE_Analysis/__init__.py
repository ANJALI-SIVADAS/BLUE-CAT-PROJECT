# Copyright 2018 BlueCat Networks. All rights reserved.
# -*- coding: utf-8 -*-

type = 'ui'
sub_pages = [
    {
        'name'        : 'Debian_CVE_Analysis_page',
        'title'       : u'Debian CVE Analysis',
        'endpoint'    : 'Debian_CVE_Analysis/Debian_CVE_Analysis_endpoint',
        'description' : u'Debian CVE Analysis'
    },
]
