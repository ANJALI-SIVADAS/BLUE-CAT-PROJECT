config_local = {
   # "CVE_DB_path" : '/home/gateway/PycharmProjects/Gateway/portal/bluecat_portal/workflows/Debian_CVE_Analysis/files',
   "CVE_DB_path" : '/home/baadmin/Downloads/Debian_CVE_Analysis/files'
    "Admin_password" : 'admin'
}
